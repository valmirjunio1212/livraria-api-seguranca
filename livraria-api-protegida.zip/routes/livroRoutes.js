const express = require('express');
const router = express.Router();
const controller = require('../controllers/LivroController');
const { autenticarToken, exigirRole } = require('../middlewares/authMiddleware');

router.get('/', controller.listar);
router.get('/:id', controller.buscarPorId);
router.post('/:id/comentarios', autenticarToken, controller.adicionarComentario);
router.post('/', autenticarToken, exigirRole('ADMIN'), controller.criar);

module.exports = router;
