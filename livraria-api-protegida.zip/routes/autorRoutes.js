const express = require('express');
const router = express.Router();
const controller = require('../controllers/AutorController');
const { autenticarToken, exigirRole } = require('../middlewares/authMiddleware');

router.post('/', autenticarToken, exigirRole('ADMIN'), controller.criar);

module.exports = router;
