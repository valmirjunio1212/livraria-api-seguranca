// Banco de dados em memória simulado para persistência temporária durante os testes
class LivrariaRepository {
  constructor() {
    this.usuarios = [];
    this.livros = [
      { id: 1, titulo: "O Senhor dos Anéis", autorId: 1, comentarios: [] },
      { id: 2, titulo: "Dom Casmurro", autorId: 2, comentarios: [] }
    ];
    this.autores = [
      { id: 1, nome: "J.R.R. Tolkien" },
      { id: 2, nome: "Machado de Assis" }
    ];
    this.proximoUsuarioId = 1;
    this.proximoLivroId = 3;
    this.proximoAutorId = 3;
  }

  buscarUsuarioPorEmail(email) {
    return this.usuarios.find(u => u.email === email);
  }

  salvarUsuario(usuario) {
    const novoUsuario = { id: this.proximoUsuarioId++, ...usuario };
    this.usuarios.push(novoUsuario);
    return novoUsuario;
  }

  listarLivros() {
    return this.livros;
  }

  buscarLivroPorId(id) {
    return this.livros.find(l => l.id === parseInt(id));
  }

  salvarLivro(livro) {
    const novoLivro = { id: this.proximoLivroId++, ...livro, comentarios: [] };
    this.livros.push(novoLivro);
    return novoLivro;
  }

  atualizarLivro(livro) {
    const idx = this.livros.findIndex(l => l.id === livro.id);
    if (idx !== -1) {
      this.livros[idx] = livro;
    }
    return livro;
  }

  salvarAutor(autor) {
    const novoAutor = { id: this.proximoAutorId++, ...autor };
    this.autores.push(novoAutor);
    return novoAutor;
  }
}

module.exports = new LivrariaRepository();
