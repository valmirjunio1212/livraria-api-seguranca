const service = require('../services/LivroService');

class LivroController {
  listar(req, res, next) {
    try {
      const livros = service.listar();
      res.status(200).json(livros);
    } catch (err) {
      next(err);
    }
  }

  buscarPorId(req, res, next) {
    try {
      const livro = service.buscarPorId(req.params.id);
      res.status(200).json(livro);
    } catch (err) {
      next(err);
    }
  }

  criar(req, res, next) {
    try {
      const novoLivro = service.criar(req.body);
      res.status(201).json(novoLivro);
    } catch (err) {
      next(err);
    }
  }

  adicionarComentario(req, res, next) {
    try {
      // req.usuario foi injetado pelo autenticarToken
      const nomeUsuario = req.usuario.nome;
      const { texto } = req.body;
      const livroAtualizado = service.adicionarComentario(req.params.id, nomeUsuario, texto);
      res.status(201).json(livroAtualizado);
    } catch (err) {
      next(err);
    }
  }
}

module.exports = new LivroController();
