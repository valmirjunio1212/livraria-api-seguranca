const service = require('../services/AuthService');

class AuthController {
  async registrar(req, res, next) {
    try {
      const resultado = await service.registrar(req.body);
      res.status(201).json(resultado);
    } catch (err) {
      next(err);
    }
  }

  async login(req, res, next) {
    try {
      const resultado = await service.login(req.body);
      res.status(200).json(resultado);
    } catch (err) {
      next(err);
    }
  }
}

module.exports = new AuthController();
