const service = require('../services/AutorService');

class AutorController {
  criar(req, res, next) {
    try {
      const novoAutor = service.criar(req.body);
      res.status(201).json(novoAutor);
    } catch (err) {
      next(err);
    }
  }
}

module.exports = new AutorController();
