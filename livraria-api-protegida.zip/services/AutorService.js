const repository = require('../repositories/LivrariaRepository');

class AutorService {
  criar(dados) {
    if (!dados.nome) {
      throw { status: 400, message: "O nome do autor é obrigatório." };
    }
    return repository.salvarAutor(dados);
  }
}

module.exports = new AutorService();
