const repository = require('../repositories/LivrariaRepository');

class LivroService {
  listar() {
    return repository.listarLivros();
  }

  buscarPorId(id) {
    const livro = repository.buscarLivroPorId(id);
    if (!livro) {
      throw { status: 404, message: "Livro não encontrado." };
    }
    return livro;
  }

  criar(dados) {
    if (!dados.titulo || !dados.autorId) {
      throw { status: 400, message: "Título e autorId são obrigatórios." };
    }
    return repository.salvarLivro(dados);
  }

  adicionarComentario(id, nomeUsuario, texto) {
    if (!texto) {
      throw { status: 400, message: "O texto do comentário é obrigatório." };
    }
    const livro = this.buscarPorId(id);
    livro.comentarios.push({ usuario: nomeUsuario, texto, data: new Date() });
    return repository.atualizarLivro(livro);
  }
}

module.exports = new LivroService();
